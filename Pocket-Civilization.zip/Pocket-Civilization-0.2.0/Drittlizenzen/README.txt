Bibliotheken des Browserbuilds

@pixi/colord 2.9.6 — MIT
@types/earcut 3.0.0 — MIT
@webgpu/types 0.1.74 — BSD-3-Clause
@xmldom/xmldom 0.8.15 — MIT
earcut 3.2.4 — ISC
eventemitter3 5.0.4 — MIT
gifuct-js 2.1.2 — MIT
ismobilejs 1.1.1 — MIT
js-binary-schema-parser 2.0.3 — MIT
parse-svg-path 0.2.0 — MIT
pixi.js 8.22.0 — MIT
tiny-lru 11.4.7 — BSD-3-Clause
