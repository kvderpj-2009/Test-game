Lizenztexte und Versionsangaben der installierten Laufzeitbibliotheken.
Die eigenen Spielgrafiken werden im Projekt prozedural gezeichnet.
Quellen ergänzter Lizenztexte und deren Prüfsummen: Quellen.json.
